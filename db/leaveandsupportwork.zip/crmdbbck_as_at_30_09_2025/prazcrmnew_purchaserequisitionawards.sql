-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchaserequisitionawards`
--

DROP TABLE IF EXISTS `purchaserequisitionawards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaserequisitionawards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` int NOT NULL,
  `item` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchaserequisition_id` bigint unsigned NOT NULL,
  `customer_id` bigint unsigned NOT NULL,
  `currency_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `quantity` int NOT NULL,
  `tendernumber` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `created_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchaserequisitionawards_uuid_unique` (`uuid`),
  KEY `purchaserequisitionawards_purchaserequisition_id_foreign` (`purchaserequisition_id`),
  KEY `purchaserequisitionawards_customer_id_foreign` (`customer_id`),
  CONSTRAINT `purchaserequisitionawards_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `purchaserequisitionawards_purchaserequisition_id_foreign` FOREIGN KEY (`purchaserequisition_id`) REFERENCES `purchaserequisitions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaserequisitionawards`
--

LOCK TABLES `purchaserequisitionawards` WRITE;
/*!40000 ALTER TABLE `purchaserequisitionawards` DISABLE KEYS */;
INSERT INTO `purchaserequisitionawards` VALUES (1,'698d13c2-60e5-4778-8ce3-df8d869f069e',2025,'zxcczczxcxzcz',8,1,1,30.00,3,'TENDER01','APPROVED','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-07-04 11:16:36','2025-07-07 16:31:49'),(3,'0552671e-dc2a-4a3d-8a79-5ffb946ee5ba',2025,'dsffsdfdsfds',8,50294,1,150.00,1,'TENDER01','APPROVED','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-07-04 11:24:04','2025-07-07 16:31:49'),(5,'c49f42d8-31ee-4c8a-b63a-360c642f634d',2025,'dsfdsfdsfds',10,1,1,450.00,2,'TENDER01','APPROVED','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-07-04 14:05:42','2025-07-04 14:52:29'),(6,'a16f88da-93ca-40d1-88e2-a527f4c9b6cd',2025,'vbcbvcbv',10,50294,1,500.00,3,'TENDER03','APPROVED','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-07-04 14:25:30','2025-07-04 14:52:29'),(7,'2ec03195-0ea6-4c78-bba5-0bf5e19b4adf',2025,'ghjghjghjhgjgj',11,1,1,450.00,1,'TENDER08','APPROVED','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-07-07 15:47:23','2025-07-07 15:49:04'),(8,'367a8a41-d68b-488e-ad5a-6e8cecde0646',2025,'sdffsdfsdf',12,50294,1,50.00,1,'TENDER04','APPROVED','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-07-09 06:18:57','2025-07-09 06:19:43'),(9,'2e95e50f-1aef-42d1-815d-4d7d10346215',2025,'sdfdsffsdf',9,50294,1,150.00,1,'TENDER01','APPROVED','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-07-29 01:13:25','2025-07-29 01:14:27');
/*!40000 ALTER TABLE `purchaserequisitionawards` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:41
