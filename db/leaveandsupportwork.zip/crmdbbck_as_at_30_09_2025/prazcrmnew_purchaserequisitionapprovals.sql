-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchaserequisitionapprovals`
--

DROP TABLE IF EXISTS `purchaserequisitionapprovals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaserequisitionapprovals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchaserequisition_id` bigint unsigned NOT NULL,
  `workflowparameter_id` bigint unsigned NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchaserequisitionapprovals_purchaserequisition_id_foreign` (`purchaserequisition_id`),
  KEY `purchaserequisitionapprovals_workflowparameter_id_foreign` (`workflowparameter_id`),
  CONSTRAINT `purchaserequisitionapprovals_purchaserequisition_id_foreign` FOREIGN KEY (`purchaserequisition_id`) REFERENCES `purchaserequisitions` (`id`),
  CONSTRAINT `purchaserequisitionapprovals_workflowparameter_id_foreign` FOREIGN KEY (`workflowparameter_id`) REFERENCES `workflowparameters` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaserequisitionapprovals`
--

LOCK TABLES `purchaserequisitionapprovals` WRITE;
/*!40000 ALTER TABLE `purchaserequisitionapprovals` DISABLE KEYS */;
INSERT INTO `purchaserequisitionapprovals` VALUES (1,8,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','dfsdfsdfdf','2025-07-03 16:21:09','2025-07-03 16:21:09'),(2,8,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfdsfdsfsdfddds','2025-07-03 16:22:10','2025-07-03 16:22:10'),(3,8,2,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfdsfdsfsdfddds','2025-07-03 16:22:28','2025-07-03 16:22:28'),(4,8,3,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfdsfdsfsdfddds','2025-07-03 16:22:38','2025-07-03 16:22:38'),(5,8,4,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfdsfdsfsdfddds','2025-07-03 16:22:42','2025-07-03 16:22:42'),(6,8,5,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','asdasdsa','2025-07-03 16:32:45','2025-07-03 16:32:45'),(8,8,6,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfsdfdsfdsfds','2025-07-03 16:46:40','2025-07-03 16:46:40'),(9,9,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','gfgfgfd','2025-07-04 08:56:54','2025-07-04 08:56:54'),(10,9,2,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','dsaassdsads','2025-07-04 08:57:32','2025-07-04 08:57:32'),(11,10,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','assad','2025-07-04 12:31:37','2025-07-04 12:31:37'),(12,10,2,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','dsddsada','2025-07-04 12:35:07','2025-07-04 12:35:07'),(13,10,3,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdsdsfddsfsd','2025-07-04 12:35:15','2025-07-04 12:35:15'),(14,10,4,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfdsffsd','2025-07-04 12:35:26','2025-07-04 12:35:26'),(15,10,5,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','dsfsdfds','2025-07-04 12:35:33','2025-07-04 12:35:33'),(16,10,6,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','dffdgdfg','2025-07-04 12:38:33','2025-07-04 12:38:33'),(17,11,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','guigkhjkghjkgj','2025-07-07 15:41:50','2025-07-07 15:41:50'),(18,11,2,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','hjkjhhj','2025-07-07 15:42:31','2025-07-07 15:42:31'),(19,11,3,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','fgjfjg','2025-07-07 15:42:45','2025-07-07 15:42:45'),(20,11,4,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','hgjgjhg','2025-07-07 15:43:02','2025-07-07 15:43:02'),(21,11,5,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','gcgfhgf','2025-07-07 15:43:14','2025-07-07 15:43:14'),(22,11,6,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','hgjhgjjgh','2025-07-07 15:44:37','2025-07-07 15:44:37'),(23,9,3,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','bvnbvnv','2025-07-08 11:36:23','2025-07-08 11:36:23'),(24,12,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','vcxvcxvcxv','2025-07-08 16:55:09','2025-07-08 16:55:09'),(25,13,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','dfgdfgdf','2025-07-09 06:14:45','2025-07-09 06:14:45'),(26,12,2,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfdf','2025-07-09 06:15:32','2025-07-09 06:15:32'),(27,12,3,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','dsffdsdsf','2025-07-09 06:15:50','2025-07-09 06:15:50'),(28,12,4,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfsdf','2025-07-09 06:16:11','2025-07-09 06:16:11'),(29,12,5,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfsdfd','2025-07-09 06:16:24','2025-07-09 06:16:24'),(30,12,6,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','dfdfsf','2025-07-09 06:18:06','2025-07-09 06:18:06'),(31,14,7,'9cb5a5ab-84db-487f-a689-688cdd6c3a99','APPROVED','kjhjjjhjjkhj','2025-07-29 00:47:03','2025-07-29 00:47:03'),(32,9,4,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfsdfsd','2025-07-29 01:12:00','2025-07-29 01:12:00'),(33,9,5,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfsdfsd','2025-07-29 01:12:06','2025-07-29 01:12:06'),(34,9,6,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','sdfsdfsd','2025-07-29 01:12:10','2025-07-29 01:12:10'),(35,15,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','erwerwerewr','2025-07-29 05:35:45','2025-07-29 05:35:45'),(36,15,2,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','fsdgsdg','2025-07-29 05:41:21','2025-07-29 05:41:21'),(37,15,4,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','oversee public procurement and the disposal of public assets, ensuring that these processes are transparent, fair, honest, cost-effective, and competitive. By doing so, we aim to promote accountability, efficiency, and value for money in public procurement and asset disposal, ultimately contributing to the country’s socio-economic developmen','2025-07-29 05:44:53','2025-07-29 05:44:53'),(38,15,5,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','oversee public procurement and the disposal of public assets, ensuring that these processes are transparent, fair, honest, cost-effective, and competitive. By doing so, we aim to promote accountability, efficiency, and value for money in public procurement and asset disposal, ultimately contributing to the country’s socio-economic developmen','2025-07-29 05:47:26','2025-07-29 05:47:26'),(39,15,6,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','oversee public procurement and the disposal of public assets, ensuring that these processes are transparent, fair, honest, cost-effective, and competitive. By doing so, we aim to promote accountability, efficiency, and value for money in public procurement and asset disposal, ultimately contributing to the country’s socio-economic developmen','2025-07-29 05:48:57','2025-07-29 05:48:57'),(40,16,7,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','APPROVED','esrwerwerwerwwer','2025-07-29 11:12:45','2025-07-29 11:12:45');
/*!40000 ALTER TABLE `purchaserequisitionapprovals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:37
