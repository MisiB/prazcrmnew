-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `leaverequestapprovals`
--

DROP TABLE IF EXISTS `leaverequestapprovals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leaverequestapprovals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `leaverequest_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `decision` tinyint(1) DEFAULT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaverequestapprovals`
--

LOCK TABLES `leaverequestapprovals` WRITE;
/*!40000 ALTER TABLE `leaverequestapprovals` DISABLE KEYS */;
INSERT INTO `leaverequestapprovals` VALUES (1,'7a4f42ad-1e4e-4345-834a-717080f5e83d','9cb5a5ab-84db-487f-a689-688cdd6c3a99','A',1,'Approved','2025-08-31 20:55:26','2025-08-31 21:45:47'),(2,'f6cd3fb2-773f-4354-b36e-b6061863f9ad','9cb5a5ab-84db-487f-a689-688cdd6c3a99','A',1,'Approved','2025-08-31 22:17:06','2025-08-31 22:19:37'),(3,'c2b05f8a-8f5a-4542-9c0d-16e123dba672','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-01 08:27:32','2025-09-01 09:00:25'),(4,'c3cfe2b4-5504-4ee7-8e43-2abdecb21f19','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-01 09:10:47','2025-09-01 09:28:26'),(5,'ead28e69-fab8-4103-af1a-17b37af85323','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-01 10:04:53','2025-09-01 10:14:24'),(6,'31b9ede3-0426-43a3-8a3f-ceec03e25672','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-01 10:14:53','2025-09-01 11:26:21'),(7,'a78fdfaf-506e-4f62-8c4e-47271df47837','9cb5a5ab-84db-487f-a689-688cdd6c3a99','A',1,'Approved','2025-09-01 11:32:45','2025-09-03 06:05:36'),(8,'3fa3e8bd-269e-4b2b-8b53-d5cedeb19090','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-03 06:10:32','2025-09-04 10:12:52'),(9,'43680869-e83b-4db3-bf16-3133d92d2055','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-04 10:13:39','2025-09-23 15:32:37'),(10,'21eeb86c-05df-4faf-92ba-033ed9089c3f','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-23 12:18:23','2025-09-23 12:35:13'),(11,'f22fc6c3-ed38-4a6c-9341-4c2b63892ff5','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-23 13:18:08','2025-09-23 13:20:34'),(12,'eeba8d8e-a84b-4c6e-82b0-f4d87263453f','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-23 13:21:06','2025-09-23 13:23:55'),(13,'8f5d04ca-f1af-4eaa-93fb-5f607ed12281','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-23 13:25:41','2025-09-23 13:33:06'),(14,'e6dc1d2d-6d33-4329-b6d3-34209635099f','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-23 13:33:39','2025-09-23 13:37:26'),(15,'184f9706-79a8-4618-8265-e3c1e57aa222','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-23 13:37:59','2025-09-23 13:39:38'),(16,'f17333af-a8ce-4644-af4d-3bb1487ddc42','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-23 13:40:02','2025-09-23 13:46:18'),(17,'481ffb7b-d2ba-4f13-8c26-5d5f1270df20','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','A',1,'Approved','2025-09-23 13:48:23','2025-09-23 13:56:28'),(18,'812e164a-4e84-4a7c-a876-ddbc5cc458e6','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-23 15:33:10','2025-09-23 15:34:44'),(19,'75d724f3-e389-4c8b-ba00-5c7a04ba9985','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-23 15:36:36','2025-09-23 16:19:59'),(20,'863cedd6-12e5-4ff4-8cd0-bde7436b4a19','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-23 16:20:33','2025-09-24 05:07:09'),(21,'20a7b9ac-5a57-4ac6-83ae-d071048f308b','9cb5a5ab-84db-487f-a689-688cdd6c3a99','A',1,'Approved','2025-09-24 05:37:43','2025-09-24 05:47:01'),(22,'fe12341a-a2bc-45c8-a8b7-6b6cdf9ce150','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 05:55:02','2025-09-24 06:49:46'),(23,'dc2cbc23-df8a-4c10-8540-45ab4a00b102','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 06:50:13','2025-09-24 07:47:56'),(24,'23793136-6d54-4885-949e-7109f2e2c2eb','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 07:48:27','2025-09-24 07:49:23'),(25,'f3a98c15-def3-4514-aaeb-29533cba2862','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 07:51:43','2025-09-24 07:53:08'),(26,'de8b26d9-1e34-41c8-a160-9d3e2d8149f9','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 07:53:27','2025-09-24 07:55:15'),(27,'caf4d247-2930-41fa-9300-eb0bd8bfdf0c','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 08:17:52','2025-09-24 08:29:12'),(28,'8d84d707-3f7d-432d-b159-88f676b25ee4','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 08:34:54','2025-09-24 08:41:13'),(29,'f017be5f-8f50-4013-bc55-29f72438073e','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 08:43:28','2025-09-24 08:48:07'),(30,'e8b68513-c262-42aa-80f3-888976f319e0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 08:51:42','2025-09-24 08:56:42'),(31,'82911440-e008-460f-a522-d4d9761e317d','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 09:05:23','2025-09-24 09:43:45'),(32,'0426b6b0-818e-4d5e-a93f-18ee3abb2365','9cb5a5ab-84db-487f-a689-688cdd6c3a99','C',NULL,'Request cancelled by user','2025-09-24 09:58:24','2025-09-24 10:11:03'),(33,'e78477e8-e416-4d75-9b11-2d0e7b0f4d63','9cb5a5ab-84db-487f-a689-688cdd6c3a99','A',1,'Approved','2025-09-24 10:11:51','2025-09-24 10:52:19'),(34,'ca0020cb-e578-45a6-983c-ed6b100e7dc5','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 11:18:28','2025-09-24 11:20:03'),(35,'58e291a0-7ffd-4ff2-9826-a4d72ad5896c','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 11:20:46','2025-09-24 11:29:07'),(36,'c7137622-55fd-45a2-936a-158029eb0c91','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','C',NULL,'Request cancelled by user','2025-09-24 11:42:56','2025-09-24 11:54:46'),(37,'62811b78-297a-407c-a722-fad359e16827','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','PENDING',NULL,NULL,'2025-09-24 11:55:59','2025-09-24 11:55:59');
/*!40000 ALTER TABLE `leaverequestapprovals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:40
