-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchaserequisitions`
--

DROP TABLE IF EXISTS `purchaserequisitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaserequisitions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `budgetitem_id` bigint unsigned NOT NULL,
  `year` int NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow_id` int DEFAULT NULL,
  `department_id` bigint unsigned NOT NULL,
  `prnumber` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `requested_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recommended_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fundavailable` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `comments` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchaserequisitions_budgetitem_id_foreign` (`budgetitem_id`),
  KEY `purchaserequisitions_department_id_foreign` (`department_id`),
  CONSTRAINT `purchaserequisitions_budgetitem_id_foreign` FOREIGN KEY (`budgetitem_id`) REFERENCES `budgetitems` (`id`),
  CONSTRAINT `purchaserequisitions_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaserequisitions`
--

LOCK TABLES `purchaserequisitions` WRITE;
/*!40000 ALTER TABLE `purchaserequisitions` DISABLE KEYS */;
INSERT INTO `purchaserequisitions` VALUES (7,9,2025,'9f1dd56e-4e63-46cc-9739-1173dd7cebcc',2,3,'PR2025554965',400,'sdfdsfdsf','sdffdsf','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,'N','NOT_RECOMMENDED','[{\"comment\": \"fghfghg\", \"user_id\": \"Benson\", \"created_at\": \"2025-07-03T17:07:29.395811Z\"}]','2025-07-03 11:22:47','2025-07-03 15:07:29'),(8,9,2025,'8dc9d61a-ea82-47d8-85d0-eb54feac0dc7',2,3,'PR20254355596',4,'fdsvsfsfgdsfdsfsdfsd','hgdgdggh','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Y','AWAITING_DELIVERY','[]','2025-07-03 14:13:48','2025-07-07 16:31:49'),(9,3,2025,'b5771371-3a56-42e4-a248-353654367651',2,3,'PR20254414142',1,'sdfsdfds','dsffds','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Y','AWAITING_DELIVERY',NULL,'2025-07-04 08:55:12','2025-07-29 01:14:27'),(10,9,2025,'56c9e1fd-e934-44a6-9169-c9507d530ce9',2,3,'PR20257572298',5,'asdasdsad','sadasdasd','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Y','AWAITING_DELIVERY',NULL,'2025-07-04 12:25:51','2025-07-04 14:52:29'),(11,9,2025,'bd046a16-5133-4768-a16e-5a81fcb988e3',2,3,'PR2025634063',1,'hkjghkh','hjhkhjkhh','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Y','DELIVERED',NULL,'2025-07-07 15:39:24','2025-07-08 11:48:56'),(12,12,2025,'4ade364b-bef5-4a66-8ca9-11bd3cbf6524',2,3,'PR20255058319',1,'Purchase requisitions ','sdffdsf','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Y','AWAITING_DELIVERY',NULL,'2025-07-08 16:36:18','2025-07-09 06:19:43'),(13,9,2025,'8d17ae75-fc0e-4f35-961b-932b82e68be6',2,3,'PR20251494740',1,'dfgdfgd','dfdfgdfgf','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Y','FINANCE_RECOMMENDATION',NULL,'2025-07-09 06:11:26','2025-07-09 06:14:45'),(14,9,2025,'4a0f3c43-27b8-4005-a281-01bdb9529690',2,3,'PR20255916854',1,'sdfdsfdsf','sdffdsf','9cb5a5ab-84db-487f-a689-688cdd6c3a99','9cb5a5ab-84db-487f-a689-688cdd6c3a99','Y','FINANCE_RECOMMENDATION',NULL,'2025-07-29 00:45:45','2025-07-29 00:47:03'),(15,12,2025,'dddfb9fe-e9b5-4690-9aa8-22d40b6690f5',2,3,'PR20254630652',3,'Purchase requisitions ','ssdfsdf','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Y','AWAITING_PMU',NULL,'2025-07-29 05:14:42','2025-07-29 05:48:57'),(16,2,2025,'242d228f-d512-45c8-933b-ceb40d14034c',2,3,'PR20259406958',1,'purchase of laptop',' this is a purpose work','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Y','FINANCE_RECOMMENDATION',NULL,'2025-07-29 10:47:30','2025-07-29 11:12:45');
/*!40000 ALTER TABLE `purchaserequisitions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:38
