-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `storesrequisitions`
--

DROP TABLE IF EXISTS `storesrequisitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storesrequisitions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `storesrequisition_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `requisitionitems` json NOT NULL,
  `purposeofrequisition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `initiator_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `storesrequisitions_storesrequisition_uuid_unique` (`storesrequisition_uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storesrequisitions`
--

LOCK TABLES `storesrequisitions` WRITE;
/*!40000 ALTER TABLE `storesrequisitions` DISABLE KEYS */;
INSERT INTO `storesrequisitions` VALUES (1,'cdf1a473-d995-416e-8cd4-a5064cf195c2','[{\"itemdetail\": \"Pens\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"requiredquantity\": \"10\"}]','Pen requisition for finance department','R','9d769685-f408-4d32-8f6a-75797d039764','2025-08-28 04:24:35','2025-08-29 10:55:55'),(2,'b6591ddd-7062-4fea-a838-ca6e2a6a0f77','[{\"itemdetail\": \"Pens\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"issuedquantity\": \"8\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Bond paper\", \"issuedquantity\": \"3\", \"requiredquantity\": \"3\"}]','Stationary requisition for ICT department','V','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-08-28 04:45:49','2025-08-28 16:30:10'),(3,'e0f9c436-2dd9-4edc-840b-180b7d0ca83e','[{\"itemdetail\": \"Rubbers\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}]','Approved ICT Test Requisition','C','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-08-28 04:56:30','2025-08-29 01:01:45'),(4,'f7f61e5f-b368-4ce9-8f6c-4fe4c623f4e6','[{\"itemdetail\": \"Rubbers\", \"requiredquantity\": \"8\"}]','Open ICT Test Requisition','P','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-08-28 04:57:08','2025-08-28 04:57:08'),(5,'76287ec2-1ce3-4136-ad82-691352b793f8','[{\"itemdetail\": \"Rubbers\", \"requiredquantity\": \"15\"}]','Cleared ICT Test Requisition','P','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-08-28 04:57:30','2025-08-28 04:57:30'),(6,'36d1c83f-e3c0-4256-95fb-0b1f4bd579a8','[{\"itemdetail\": \"Rubbers\", \"requiredquantity\": \"9\"}]','Delivered ICT Test Requisition','P','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-08-28 04:58:03','2025-08-28 04:58:03'),(7,'b65c732f-0188-444e-b529-d3c5241a1af6','[{\"itemdetail\": \"Pens\", \"issuedquantity\": \"9\", \"requiredquantity\": \"9\"}]','Approved FINANCE Test Requisition','V','9d769685-f408-4d32-8f6a-75797d039764','2025-08-28 04:58:44','2025-08-29 13:55:19'),(8,'77aa83dc-267e-4feb-bfbf-ff8c5ae2bea9','[{\"itemdetail\": \"Pens\", \"requiredquantity\": \"9\"}]','Opened FINANCE Test Requisition','P','9d769685-f408-4d32-8f6a-75797d039764','2025-08-28 04:59:03','2025-08-28 04:59:03'),(9,'fa584ebf-8a82-4e0c-8fc9-77226d0d2e95','[{\"itemdetail\": \"Pens\", \"requiredquantity\": \"8\"}]','Delivered FINANCE Test Requisition','P','9d769685-f408-4d32-8f6a-75797d039764','2025-08-28 04:59:24','2025-08-28 04:59:24'),(10,'cc4dbec4-0dce-4e73-91a3-52614c51b8f6','[{\"itemdetail\": \"Pens\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"requiredquantity\": \"8\"}]','Approve Finance Test Requisition','O','9d769685-f408-4d32-8f6a-75797d039764','2025-08-28 05:02:16','2025-08-30 16:36:52'),(11,'13925e78-466c-4270-abb5-4a3230b5c92e','[{\"itemdetail\": \"Pens\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"issuedquantity\": \"8\", \"requiredquantity\": \"8\"}]','Opened Finance Test Requisition','D','9d769685-f408-4d32-8f6a-75797d039764','2025-08-28 05:02:38','2025-08-30 15:09:15'),(12,'2eb21b94-22af-4044-a32c-08133f1b10dc','[{\"itemdetail\": \"Rubbers\", \"requiredquantity\": \"8\"}, {\"itemdetail\": \"Notepads\", \"requiredquantity\": \"8\"}]','Delivered Finance Test Requisition','R','9d769685-f408-4d32-8f6a-75797d039764','2025-08-28 05:03:08','2025-08-29 15:50:09'),(13,'352b22a6-b9b3-45aa-aa94-0fba7798ec26','[{\"itemdetail\": \"Pens\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"requiredquantity\": \"10\"}]','Multi-User test requisition for ICT department','P','9e6c1e8d-03b1-40cd-a184-d68cd15a102a','2025-08-28 09:38:44','2025-08-28 09:38:44'),(14,'fc95a926-4cb2-461a-bea1-7546b8b1180f','[{\"itemdetail\": \"Rubbers\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}]','Finance Test Request for whole flow','C','9d769685-f408-4d32-8f6a-75797d039764','2025-08-29 14:07:44','2025-08-29 15:08:07'),(15,'88c3460a-914e-4bee-acd8-535841cf7fa5','[{\"itemdetail\": \"Rubbers\", \"requiredquantity\": \"10\"}]','Test for recall','R','9d769685-f408-4d32-8f6a-75797d039764','2025-08-29 15:51:05','2025-08-29 15:51:22'),(16,'57e0e1a0-eee7-4a50-b4a6-fe4591eb9067','[{\"itemdetail\": \"Rubbers\", \"issuedquantity\": \"8\", \"requiredquantity\": \"8\"}, {\"itemdetail\": \"Notepads\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}]','Test Finance requisition for email notifications flow','V','9d769685-f408-4d32-8f6a-75797d039764','2025-08-30 13:44:13','2025-08-30 14:40:26'),(17,'22167741-a377-4cd4-8e6e-343beb63bae4','[{\"itemdetail\": \"Pens\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}]','Test 2 Finance requisition for email notifications flow','V','9d769685-f408-4d32-8f6a-75797d039764','2025-08-30 14:04:18','2025-08-30 14:57:34'),(18,'23fab05a-1e6a-46e7-b7c1-b34d67ee20e6','[{\"itemdetail\": \"Pens\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"issuedquantity\": \"8\", \"requiredquantity\": \"8\"}]','Test 3 Finance requisition for email notifications flow','V','9d769685-f408-4d32-8f6a-75797d039764','2025-08-30 14:33:20','2025-08-30 15:01:34'),(19,'a4b0e7e6-66ea-406a-bd2b-4eef32f74794','[{\"itemdetail\": \"Pens\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}]','Test 2 for full flow','C','9d769685-f408-4d32-8f6a-75797d039764','2025-08-30 16:04:21','2025-08-30 16:21:46'),(20,'9b37470d-1044-45bf-b8d8-2d9a5989bbef','[{\"itemdetail\": \"Rubbers\", \"issuedquantity\": \"10\", \"requiredquantity\": \"10\"}]','Final test all rounder','C','9d769685-f408-4d32-8f6a-75797d039764','2025-08-30 16:28:44','2025-08-30 16:42:45'),(21,'30107ecc-3365-44ab-92ce-96ae808a3dc4','[{\"itemdetail\": \"Tea bags\", \"requiredquantity\": \"10\"}]','Departmental usage','P','9e86a252-68a9-47e4-b688-0d04387f594c','2025-08-31 19:16:34','2025-08-31 19:16:34'),(22,'f708dc14-3c6b-4c1c-95c2-34c0d260dabf','[{\"itemdetail\": \"Pens\", \"issuedquantity\": \"50\", \"requiredquantity\": \"50\"}, {\"itemdetail\": \"Notepads\", \"issuedquantity\": \"12\", \"requiredquantity\": \"12\"}]','Migration Test: To prazcrmnew repo','C','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-09-18 10:43:07','2025-09-18 13:48:03'),(23,'c8258f55-77a2-4629-888b-13b1aa179e06','[{\"itemdetail\": \"Tare\", \"requiredquantity\": \"50\"}]','Services Test: To prazcrmnew repo','A','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-09-19 08:42:03','2025-09-19 08:45:20'),(24,'67753bd5-0c8f-4831-9094-57572c246e89','[{\"itemdetail\": \"Pens\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"requiredquantity\": \"8\"}]','Services Test 2: To prazcrmnew repo','R','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-09-19 08:44:05','2025-09-19 08:44:17'),(25,'8a2c3a9b-bf5e-4bdb-bf7c-317c1369b890','[{\"itemdetail\": \"Pens\", \"requiredquantity\": \"10\"}, {\"itemdetail\": \"Notepads\", \"requiredquantity\": \"12\"}]','Services Test 3: To prazcrmnew repo','A','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-09-19 08:46:46','2025-09-19 08:47:15');
/*!40000 ALTER TABLE `storesrequisitions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:07
