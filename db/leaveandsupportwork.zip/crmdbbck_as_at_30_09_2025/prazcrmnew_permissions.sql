-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submodule_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`),
  KEY `permissions_submodule_id_index` (`submodule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'accounttype.view','web',1,'2025-03-20 13:20:19','2025-03-20 13:20:19'),(2,'settings.view','web',1,'2025-03-20 13:20:20','2025-03-20 13:29:28'),(3,'accounttype.modify','web',1,'2025-03-20 13:27:56','2025-03-20 13:27:56'),(4,'roles.view','web',2,'2025-03-20 13:30:10','2025-03-20 13:30:10'),(5,'roles.modify','web',2,'2025-03-20 13:32:20','2025-03-20 13:32:20'),(6,'roles.assign','web',2,'2025-03-20 13:33:56','2025-03-20 13:33:56'),(7,'roles.delete','web',2,'2025-03-20 13:36:31','2025-03-20 13:36:31'),(8,'modules.view','web',3,'2025-03-20 14:07:57','2025-03-20 14:07:57'),(9,'modules.modify','web',3,'2025-03-20 14:08:16','2025-03-20 14:08:16'),(10,'users.view','web',4,'2025-03-20 14:09:17','2025-03-20 14:09:17'),(11,'user.modify','web',4,'2025-03-20 14:09:32','2025-03-20 14:09:32'),(12,'users.delete','web',4,'2025-03-20 14:09:41','2025-03-20 14:09:41'),(36,'currency.access','web',24,'2025-03-28 08:36:22','2025-03-28 08:36:22'),(38,'currency.modify','web',24,'2025-03-28 08:36:32','2025-03-28 08:36:32'),(53,'finance.access','web',24,'2025-03-28 08:36:32','2025-03-28 08:36:32'),(54,'paynowconfiguration.access','web',24,'2025-04-25 13:13:27','2025-04-25 13:13:27'),(55,'paynowconfiguration.modify','web',24,'2025-04-25 13:13:38','2025-04-25 13:13:38'),(56,'inventoryitems.access','web',24,'2025-04-25 13:13:53','2025-04-25 13:13:53'),(57,'inventoryitems.modify','web',24,'2025-04-25 13:14:06','2025-04-25 13:14:06'),(58,'finance.reports.access','web',25,'2025-04-25 13:37:26','2025-04-25 13:37:26'),(59,'finance.banktransaction.access','web',26,'2025-04-28 08:36:28','2025-04-28 08:36:28'),(61,'finance.suspensereports.access','web',27,'2025-04-29 06:36:50','2025-04-29 06:36:50'),(62,'tendertypes.access','web',29,'2025-05-05 12:09:41','2025-05-05 12:09:41'),(63,'tender.access','web',29,'2025-05-05 12:09:41','2025-05-05 12:09:41'),(64,'tenders.modify','web',28,'2025-05-05 12:11:18','2025-05-05 12:11:18'),(65,'wallettopup.access','web',30,'2025-05-29 17:03:25','2025-05-29 17:03:25'),(66,'wallettopup.process','web',30,'2025-05-29 17:03:44','2025-05-29 17:03:44'),(67,'department.access','web',31,'2025-05-30 07:15:24','2025-05-30 07:15:24'),(68,'department.modify','web',31,'2025-05-30 07:15:34','2025-05-30 07:15:34'),(69,'strategy.access','web',32,'2025-06-01 14:42:58','2025-06-01 14:42:58'),(70,'management.access','web',32,'2025-06-01 14:42:58','2025-06-01 14:42:58'),(71,'strategy.create','web',32,'2025-06-01 14:43:14','2025-06-01 14:43:14'),(72,'strategy.update','web',32,'2025-06-01 14:43:25','2025-06-01 14:43:25'),(73,'strategy.approve','web',32,'2025-06-01 14:43:34','2025-06-01 14:43:34'),(74,'subprogrammeoutput.access','web',33,'2025-06-02 12:35:34','2025-06-02 12:35:34'),(75,'subprogrammeoutput.create','web',33,'2025-06-02 12:35:54','2025-06-02 12:35:54'),(76,'subprogrammeoutput.update','web',33,'2025-06-02 12:36:01','2025-06-02 12:36:01'),(77,'subprogrammeoutput.delete','web',33,'2025-06-02 12:36:08','2025-06-02 12:36:08'),(78,'subprogrammeoutput.approve','web',33,'2025-06-02 12:36:14','2025-06-02 12:36:14'),(80,'workplan.create','web',34,'2025-06-03 14:24:30','2025-06-03 14:43:42'),(81,'workplan.update','web',34,'2025-06-03 14:24:37','2025-06-03 14:43:50'),(82,'workplan.delete','web',34,'2025-06-03 14:24:44','2025-06-03 14:44:03'),(83,'workplan.approve','web',34,'2025-06-03 14:24:51','2025-06-03 14:44:11'),(84,'workplan.access','web',34,'2025-06-03 14:43:14','2025-06-03 14:43:14'),(85,'budgetconfiguration.access','web',35,'2025-06-18 13:14:08','2025-06-18 13:14:08'),(86,'budgets.access','web',35,'2025-06-18 13:14:08','2025-06-18 13:14:08'),(87,'budgetconfiguration.modify','web',35,'2025-06-18 13:14:21','2025-06-18 13:14:21'),(88,'budgets.modify','web',35,'2025-06-18 13:14:36','2025-06-18 13:14:36'),(89,'budgets.approve','web',35,'2025-06-18 13:14:43','2025-06-18 13:14:43'),(90,'consolidatedbudget.access','web',36,'2025-06-18 14:35:43','2025-06-18 14:35:43'),(91,'consolidatedbudget.modify','web',36,'2025-06-18 14:35:52','2025-06-18 14:35:52'),(92,'consolidatedbudget.approve','web',36,'2025-06-18 14:36:03','2025-06-18 14:36:03'),(93,'departmentbudget.access','web',37,'2025-06-18 17:40:52','2025-06-18 17:40:52'),(94,'departmentbudget.modify','web',37,'2025-06-18 17:41:05','2025-06-18 17:41:05'),(95,'departmentbudget.approve','web',37,'2025-06-18 17:41:13','2025-06-18 17:41:13'),(96,'workflow.configuration.access','web',38,'2025-07-01 09:38:07','2025-07-01 09:38:07'),(97,'workflow.access','web',38,'2025-07-01 09:38:07','2025-07-01 09:38:07'),(98,'workflow.configuration.modify','web',38,'2025-07-01 09:38:42','2025-07-01 09:38:42'),(99,'workflow.modify','web',38,'2025-07-01 09:38:52','2025-07-01 09:38:52'),(101,'PURCHASEREQ.APPROVAL','web',38,'2025-07-01 12:34:29','2025-07-03 05:07:06'),(102,'PURCHASEREQS.FINANCE.RECOMMEND','web',38,'2025-07-03 05:07:30','2025-07-03 05:07:30'),(103,'PURCHASEREQS.FINANCE.APPROVAL','web',38,'2025-07-03 05:07:52','2025-07-03 05:07:52'),(104,'PURCHASEREQS.ADMIN.APPROVAL','web',38,'2025-07-03 05:08:17','2025-07-03 05:08:17'),(105,'PURCHASEREQS.ADMIN.RECOMMEND','web',38,'2025-07-03 05:11:02','2025-07-03 05:11:02'),(106,'purchaserequisition.access','web',39,'2025-07-03 07:43:40','2025-07-03 07:43:40'),(107,'purchaserequisition.modify','web',39,'2025-07-03 07:43:53','2025-07-03 07:43:53'),(108,'purchaserequisition.recommend','web',39,'2025-07-03 07:44:04','2025-07-03 07:44:04'),(109,'BUDGET_CONFIRMATION','web',38,'2025-07-03 15:47:02','2025-07-03 15:47:02'),(110,'approval.purchaserequisition.access','web',40,'2025-07-04 07:02:16','2025-07-04 07:02:16'),(111,'approval.access','web',40,'2025-07-04 07:02:16','2025-07-04 07:02:16'),(112,'PURCHASEREQS.PMU','web',38,'2025-07-04 08:16:42','2025-07-04 08:16:42'),(113,'procurement.access','web',41,'2025-07-04 09:14:14','2025-07-04 09:14:14'),(114,'procurement.modify','web',41,'2025-07-04 09:14:23','2025-07-04 09:14:23'),(115,'procurement.approve','web',41,'2025-07-04 09:14:30','2025-07-04 09:14:30'),(116,'ADMIN.DELIVERY.ACCESS','web',42,'2025-07-04 14:44:11','2025-07-04 14:44:11'),(117,'ADMIN.DELIVERY.MODIFY','web',42,'2025-07-04 14:44:27','2025-07-04 14:44:27'),(118,'ADMIN.DELIVERY.APPROVE','web',42,'2025-07-04 14:44:35','2025-07-04 14:44:35'),(119,'revenue.posting','web',43,'2025-07-06 13:33:17','2025-07-06 13:33:17'),(120,'revenue.posting.approval','web',43,'2025-07-06 13:33:38','2025-07-06 13:33:38'),(121,'leavetype.view','web',44,'2025-07-29 00:12:45','2025-07-29 00:12:45'),(122,'leavestatements.access','web',45,'2025-07-29 00:17:40','2025-07-29 00:17:40'),(123,'leaverequests.access','web',46,'2025-07-29 00:17:43','2025-07-29 00:17:43'),(124,'performancetracker.access','web',47,'2025-07-29 06:40:45','2025-07-29 06:40:45'),(125,'trackers.access','web',47,'2025-07-29 06:40:45','2025-07-29 06:40:45'),(126,'budgettracker.access','web',48,'2025-07-29 06:50:27','2025-07-29 06:50:27'),(127,'weeklytasks.access','web',49,'2025-09-15 16:43:23','2025-09-15 16:43:23'),(128,'weeklytasks.approve','web',49,'2025-09-15 16:43:39','2025-09-15 16:43:39'),(129,'storesrequisitions.approvals','web',51,'2025-09-18 08:30:45','2025-09-18 08:30:45'),(130,'storesrequisitions.deliveries','web',52,'2025-09-18 08:30:51','2025-09-18 08:30:51'),(131,'storesrequisitions.access','web',50,'2025-09-18 08:31:10','2025-09-18 08:31:10'),(132,'issuelog.dashboard','web',53,'2025-09-20 12:54:55','2025-09-20 12:54:55'),(133,'support.access','web',53,'2025-09-20 12:54:55','2025-09-20 12:54:55'),(134,'issuelog.access','web',54,'2025-09-20 12:54:59','2025-09-20 12:54:59'),(135,'issuelog.assigned','web',55,'2025-09-20 12:55:02','2025-09-20 12:55:02'),(136,'peissuelog.access','web',56,'2025-09-20 12:55:23','2025-09-20 12:55:23'),(137,'pesupport.access','web',56,'2025-09-20 12:55:23','2025-09-20 12:55:23'),(138,'bidderissuelog.access','web',57,'2025-09-20 12:55:33','2025-09-20 12:55:33'),(139,'biddersupport.access','web',57,'2025-09-20 12:55:34','2025-09-20 12:55:34');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:40
