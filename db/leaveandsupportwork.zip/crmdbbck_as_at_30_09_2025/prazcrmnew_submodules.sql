-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `submodules`
--

DROP TABLE IF EXISTS `submodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submodules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_id` bigint unsigned DEFAULT NULL,
  `default_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `submodules_module_id_index` (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submodules`
--

LOCK TABLES `submodules` WRITE;
/*!40000 ALTER TABLE `submodules` DISABLE KEYS */;
INSERT INTO `submodules` VALUES (1,'Account types','account-types','o-wrench-screwdriver','admin.configuration.accounttypes',2,'accounttype.view',NULL,NULL,'2025-03-04 11:46:22','2025-03-20 13:15:22'),(2,'Roles','roles','o-shield-check','admin.configuration.roles',2,'roles.view',NULL,NULL,'2025-03-04 11:54:35','2025-03-20 13:15:25'),(3,'Modules','modules','o-link','admin.configuration.modules',2,'modules.view',NULL,NULL,'2025-03-04 11:55:54','2025-03-20 13:15:28'),(4,'User','user','o-users','admin.configuration.users',2,'users.view',NULL,NULL,'2025-03-04 11:56:41','2025-03-20 13:15:30'),(24,'Settings','user','o-users','admin.finance.configurations',5,'finance.access',NULL,NULL,'2025-03-04 11:56:41','2025-03-20 13:15:30'),(25,'Reports','reports','o-chart-pie','admin.finance.reports',5,'finance.reports.access',NULL,NULL,'2025-04-25 13:37:18','2025-04-29 06:36:38'),(26,'Bank transactions','bank-transactions','o-currency-dollar','admin.finance.banktransactions',5,'finance.banktransaction.access',NULL,NULL,'2025-04-28 08:36:26','2025-04-28 08:36:26'),(28,'list','list','o-list-bullet','admin.procurements.tenders',6,'tenders.modify',NULL,NULL,'2025-05-05 12:08:35','2025-05-05 12:08:35'),(29,'Types','types','o-adjustments-horizontal','admin.procurements.tendertypes',6,'tendertypes.access',NULL,NULL,'2025-05-05 12:09:38','2025-05-05 12:09:38'),(30,'Wallet topups','wallet-topups','o-wallet','admin.finance.wallettopups',5,'wallettopup.access',NULL,NULL,'2025-05-29 17:03:22','2025-05-29 17:03:22'),(31,'Departments','departments','o-archive-box','admin.configuration.departments',2,'department.access',NULL,NULL,'2025-05-30 07:15:22','2025-05-30 07:15:22'),(32,'Strategy','strategy','o-paper-airplane','admin.management.strategies',7,'strategy.access',NULL,NULL,'2025-06-01 14:42:56','2025-06-01 14:42:56'),(33,'Departmental outputs','departmental-outputs','o-document-check','admin.management.subprogrammeoutputs',7,'subprogrammeoutput.access',NULL,NULL,'2025-06-02 12:35:29','2025-06-03 14:18:34'),(34,'Workplan','workplan','o-arrow-down-on-square-stack','admin.management.workplans',7,'workplan.access',NULL,NULL,'2025-06-03 14:23:58','2025-06-03 14:43:11'),(35,'Configurations','configurations','o-wrench-screwdriver','admin.finance.budgetconfigurations.configurationlist',8,'budgetconfiguration.access',NULL,NULL,'2025-06-18 13:14:06','2025-06-18 13:14:06'),(36,'Consolidated','consolidated','o-building-library','admin.finance.budgetmanagement.budgets',8,'consolidatedbudget.access',NULL,NULL,'2025-06-18 14:35:38','2025-06-18 14:35:38'),(37,'Departmental','departmental','o-currency-dollar','admin.finance.budgetmanagement.departmentalbudgets',8,'departmentbudget.access',NULL,NULL,'2025-06-18 17:40:50','2025-06-18 17:40:50'),(38,'Workflow Configurations','workflow-configurations','o-adjustments-horizontal','admin.workflows',9,'workflow.configuration.access',NULL,NULL,'2025-07-01 09:38:05','2025-07-01 09:38:05'),(39,'Purchase requisition','purchase-requisition','o-fire','admin.workflows.purchaserequisitions',9,'purchaserequisition.access',NULL,NULL,'2025-07-03 07:43:38','2025-07-03 07:43:38'),(40,'Purchase Reqs','purchase-reqs','o-building-storefront','admin.workflows.approvals.purchaserequisitionlist',10,'approval.purchaserequisition.access',NULL,NULL,'2025-07-04 07:01:58','2025-07-04 07:01:58'),(41,'Procurement','procurement','o-heart','admin.workflows.awaitingpmu',9,'procurement.access',NULL,NULL,'2025-07-04 09:14:13','2025-07-04 09:14:13'),(42,'Delivary','delivary','o-archive-box-arrow-down','admin.workflows.awaitingdelivery',9,'ADMIN.DELIVERY.ACCESS',NULL,NULL,'2025-07-04 14:44:00','2025-07-04 14:44:00'),(43,'Revenue posting','revenue-posting','o-currency-dollar','admin.finance.revenueposting',5,'revenue.posting',NULL,NULL,'2025-07-06 13:33:15','2025-07-06 13:33:15'),(44,'Leave types','leave-types','o-cog-8-tooth','admin.configuration.leavetypes',2,'leavetype.view',NULL,NULL,'2025-07-29 00:11:23','2025-07-29 00:11:23'),(45,'Leave statements','leave-statements','o-cog-8-tooth','admin.workflows.leavestatements',9,'leavestatements.access',NULL,NULL,'2025-07-29 00:15:36','2025-07-29 00:15:36'),(46,'Leave requests','leave-requests','o-cog-8-tooth','admin.workflows.leaverequests',9,'leaverequests.access',NULL,NULL,'2025-07-29 00:16:54','2025-07-29 00:16:54'),(47,'Performance','performance','o-finger-print','admin.trackers.performancetracker',11,'performancetracker.access',NULL,NULL,'2025-07-29 06:40:43','2025-07-29 06:40:43'),(48,'Budget tracker','budget-tracker','o-magnifying-glass-circle','admin.trackers.budgettracker',11,'budgettracker.access',NULL,NULL,'2025-07-29 06:50:24','2025-07-29 06:50:24'),(49,'Weekly tasks','weekly-tasks','o-command-line','admin.workflows.approvals.weekytasks',10,'weeklytasks.access',NULL,NULL,'2025-09-15 16:43:21','2025-09-15 16:43:21'),(50,'My stores requisitions','my-stores-requisitions','o-cog-8-tooth','admin.workflows.storesrequisitions',9,'storesrequisitions.access',NULL,NULL,NULL,NULL),(51,'Stores approvals','stores-approvals','o-cog-8-tooth','admin.workflows.approvals.deptstoresrequisitionapprovals',10,'storesrequisitions.approvals',NULL,NULL,NULL,NULL),(52,'Stores delivery','stores-delivery','o-cog-8-tooth','admin.workflows.approvals.storesrequisitiondelivery',10,'storesrequisitions.deliveries',NULL,NULL,NULL,NULL),(53,'Issues dashboard','issues-dashboard','o-cog','admin.issues.issuelogdashboard',12,'issuelog.dashboard',NULL,NULL,NULL,NULL),(54,'Logs','logs','o-cog','admin.issues.logs',12,'issuelog.access',NULL,NULL,NULL,NULL),(55,'Assigned issues','assigned-issues','o-cog','admin.issues.assignedissues',12,'issuelog.assigned',NULL,NULL,NULL,NULL),(56,'Procuring entity logs','procuring-entity-logs','o-cog','entity.issues.log',13,'peissuelog.access',NULL,NULL,NULL,NULL),(57,'Bidder logs','bidder-logs','o-cog','bidder.issues.log',14,'bidderissuelog.access',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `submodules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:35
