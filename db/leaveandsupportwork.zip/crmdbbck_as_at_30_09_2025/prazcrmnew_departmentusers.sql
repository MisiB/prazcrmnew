-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `departmentusers`
--

DROP TABLE IF EXISTS `departmentusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departmentusers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `department_id` bigint unsigned NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isprimary` tinyint(1) NOT NULL DEFAULT '0',
  `reportto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departmentusers_department_id_foreign` (`department_id`),
  CONSTRAINT `departmentusers_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departmentusers`
--

LOCK TABLES `departmentusers` WRITE;
/*!40000 ALTER TABLE `departmentusers` DISABLE KEYS */;
INSERT INTO `departmentusers` VALUES (3,3,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','ICT OFFICER  SOFTWARE DEVELOPMENT & INTERGRATIONs',0,'9cb5a5ab-84db-487f-a689-688cdd6c3a99','2025-05-30 09:20:50','2025-05-30 09:24:15'),(4,3,'9cb5a5ab-84db-487f-a689-688cdd6c3a99','ICT OFFICER  INFRUSTRUCTURE & PROJECT COORDINATION',1,'9d0c1a06-175a-4035-9494-db35ce24087b','2025-05-30 09:21:06','2025-05-30 09:21:06'),(5,4,'9d7a657a-a7ea-453c-a9fb-a40931a7aa41','FINANCE & ADMINISTRATION DIRECTOR',1,'9d0c1a06-175a-4035-9494-db35ce24087b','2025-05-30 09:26:06','2025-05-30 09:26:06'),(6,4,'9c97ca3f-bb84-4127-8273-ef8d2048746d','FINANCE MANAGER',0,'9d7a657a-a7ea-453c-a9fb-a40931a7aa41','2025-05-30 09:26:39','2025-05-30 09:26:39'),(7,4,'9cb7c72c-ff8d-49b6-a591-4593ba885f2c','FINANCE OFFICER',0,'9c97ca3f-bb84-4127-8273-ef8d2048746d','2025-05-30 09:27:03','2025-05-30 09:27:03'),(8,3,'9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','ICT GRADUATE TRAINEE',0,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-09-18 10:15:46','2025-09-18 10:15:46'),(9,4,'9d769685-f408-4d32-8f6a-75797d039764','FINANCE OFFICER',0,'9c97ca3f-bb84-4127-8273-ef8d2048746d','2025-09-18 15:41:02','2025-09-18 15:41:02'),(10,3,'9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','ICT GT',0,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','2025-09-23 15:41:55','2025-09-23 15:41:55');
/*!40000 ALTER TABLE `departmentusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:43
