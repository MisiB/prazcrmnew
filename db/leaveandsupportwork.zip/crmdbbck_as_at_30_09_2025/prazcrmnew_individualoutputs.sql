-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `individualoutputs`
--

DROP TABLE IF EXISTS `individualoutputs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `individualoutputs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subprogrammeoutput_id` bigint unsigned NOT NULL,
  `output` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `indicator` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` int NOT NULL,
  `variance` int NOT NULL,
  `weightage` int NOT NULL,
  `createdby` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `approvedby` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `parent_id` bigint unsigned DEFAULT NULL,
  `comments` json DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `individualoutputs_uuid_unique` (`uuid`),
  KEY `individualoutputs_subprogrammeoutput_id_foreign` (`subprogrammeoutput_id`),
  KEY `individualoutputs_parent_id_foreign` (`parent_id`),
  CONSTRAINT `individualoutputs_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `individualoutputs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `individualoutputs_subprogrammeoutput_id_foreign` FOREIGN KEY (`subprogrammeoutput_id`) REFERENCES `strategysubprogrammeoutputs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `individualoutputs`
--

LOCK TABLES `individualoutputs` WRITE;
/*!40000 ALTER TABLE `individualoutputs` DISABLE KEYS */;
INSERT INTO `individualoutputs` VALUES (2,'4b9550e0-5707-4a58-96e6-f4f1f05ffdaf',3,'<p>Policies and Procedures reviewed/developed&nbsp;</p>','Number of policies reviewed',3,0,4,'9cb5a5ab-84db-487f-a689-688cdd6c3a99',NULL,'PENDING',NULL,NULL,NULL,'2025-06-10 13:25:28','2025-06-10 13:25:28','9cb5a5ab-84db-487f-a689-688cdd6c3a99'),(4,'5cab6f17-5654-4da1-b9d4-806c1eb63991',5,'<p>Electronic Tools/Systems developed</p>','Number of tools developed',3,1,9,'9cb5a5ab-84db-487f-a689-688cdd6c3a99',NULL,'PENDING',NULL,NULL,NULL,'2025-06-10 13:53:14','2025-06-10 13:53:14','9cb5a5ab-84db-487f-a689-688cdd6c3a99'),(5,'7fcf3bcc-32f8-4237-bb48-6859157f0101',3,'<p>Develop software development policy</p>','Number of policies developed',1,0,5,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,'PENDING',NULL,NULL,NULL,'2025-06-17 11:21:06','2025-06-17 11:21:06','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0'),(6,'e7a884fb-0d83-4126-b998-961762b255b1',5,'<p>Develop&nbsp;</p>\n<ul>\n<li>Monitoring and evaluation system</li>\n<li>Helpdesk ticketing system&nbsp;</li>\n<li>Conference system</li>\n</ul>','Systems developed',3,0,30,'9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,'PENDING',NULL,NULL,NULL,'2025-06-17 12:03:19','2025-06-17 12:03:19','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0'),(7,'f2e15c98-4e5f-4570-a084-55245a4d6d14',4,'<p>End to end E-GP System implemented</p>','Number of modules implemented % modules maintained',6,1,30,'9cb5a5ab-84db-487f-a689-688cdd6c3a99',NULL,'PENDING',NULL,NULL,NULL,'2025-06-18 11:27:37','2025-06-18 11:27:37','9cb5a5ab-84db-487f-a689-688cdd6c3a99');
/*!40000 ALTER TABLE `individualoutputs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:39
