-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `budgetitems`
--

DROP TABLE IF EXISTS `budgetitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `budgetitems` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget_id` bigint unsigned NOT NULL,
  `department_id` bigint unsigned NOT NULL,
  `activity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expensecategory_id` bigint unsigned NOT NULL,
  `strategysubprogrammeoutput_id` bigint unsigned NOT NULL,
  `sourceoffund_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `unitprice` float NOT NULL DEFAULT '0',
  `total` float NOT NULL DEFAULT '0',
  `currency_id` bigint unsigned NOT NULL,
  `focusdate` date NOT NULL,
  `created_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approved_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `budgetitems_budget_id_foreign` (`budget_id`),
  KEY `budgetitems_department_id_foreign` (`department_id`),
  KEY `budgetitems_expensecategory_id_foreign` (`expensecategory_id`),
  KEY `budgetitems_strategysubprogramme_id_foreign` (`strategysubprogrammeoutput_id`),
  KEY `budgetitems_sourceoffund_id_foreign` (`sourceoffund_id`),
  KEY `budgetitems_currency_id_foreign` (`currency_id`),
  CONSTRAINT `budgetitems_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`),
  CONSTRAINT `budgetitems_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `budgetitems_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `budgetitems_expensecategory_id_foreign` FOREIGN KEY (`expensecategory_id`) REFERENCES `expensecategories` (`id`),
  CONSTRAINT `budgetitems_sourceoffund_id_foreign` FOREIGN KEY (`sourceoffund_id`) REFERENCES `sourceoffunds` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgetitems`
--

LOCK TABLES `budgetitems` WRITE;
/*!40000 ALTER TABLE `budgetitems` DISABLE KEYS */;
INSERT INTO `budgetitems` VALUES (2,'0ad099f1-0932-4129-8687-c59fca6e1daa',2,3,'fgdfgfdgfdg','asdasdsad asdasdasd sdfsdfds',2,4,1,1,5,5,1,'2025-08-31','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,'APPROVED','2025-06-23 07:03:50','2025-06-24 08:37:11'),(3,'747c9f19-a627-40d0-9527-3c42e1ccab03',2,3,'fgdfgfdgfdg','dfsfsdfdsf',2,4,1,4,10,40,1,'2025-07-31','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'APPROVED','2025-06-23 09:53:36','2025-06-24 08:37:11'),(9,'d0a94e67-97c3-484a-999a-0f8f07c50a5f',2,3,'This is a test activity','zcxvxzcvxcvxcvcv',2,4,1,1000,10,10000,1,'2025-07-31','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,'APPROVED','2025-06-23 10:01:31','2025-06-24 10:19:38'),(12,'f41b4cd1-aa28-431a-98e4-788eba64148c',2,3,'fgdfgfdgfdg','fgdfgdfgf',2,5,1,19,5,95,1,'2025-08-30','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'APPROVED','2025-06-23 10:03:25','2025-06-24 08:37:11'),(13,'65995caa-a266-478f-ac4a-4f7e91112df4',2,3,'fgdfgfdgfdg','sdfffsdfsdfdsf',2,5,1,5,10,50,1,'2025-08-30','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,'APPROVED','2025-06-24 08:19:38','2025-06-24 08:37:11'),(14,'7b240039-ab38-4d64-b300-5ab02dd4b6cb',2,3,'fgdfgfdgfdg','sasdsadsadsa',2,4,1,100,10,1000,1,'2025-07-11','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'APPROVED','2025-06-24 08:43:28','2025-06-24 08:47:32'),(15,'fb5270ed-7de7-4428-bf3f-98246f46cdc2',2,3,'tesst 2','jhgsdjhgdfsjhdsfdwfgh',2,4,1,6,10,60,1,'2025-07-12','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'APPROVED','2025-06-24 14:46:01','2025-06-24 14:51:34');
/*!40000 ALTER TABLE `budgetitems` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:34:58
