-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchaserequisitionawarddocuments`
--

DROP TABLE IF EXISTS `purchaserequisitionawarddocuments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaserequisitionawarddocuments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchaserequisitionaward_id` bigint unsigned NOT NULL,
  `document` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `filepath` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaserequisitionawarddocuments`
--

LOCK TABLES `purchaserequisitionawarddocuments` WRITE;
/*!40000 ALTER TABLE `purchaserequisitionawarddocuments` DISABLE KEYS */;
INSERT INTO `purchaserequisitionawarddocuments` VALUES (1,1,'Purchase Order','awarddocuments/1CkZ83DepIRxdWTflEqGbBU12sXU4uLoJu63POmY.pdf','2025-07-04 12:18:28','2025-07-04 12:18:28'),(2,4,'Purchase Order','awarddocuments/dotrA6Nk9ZrBw6jIVndlrhawleTZLSECQdCbX1D5.pdf','2025-07-04 12:58:46','2025-07-04 12:58:46'),(3,4,'Contract','awarddocuments/nNVNM2UG4QahmdGhmNWzObBsCIvpvHHEAlqG32Zh.pdf','2025-07-04 12:59:04','2025-07-04 12:59:04'),(4,5,'Purchase Order','awarddocuments/rrB7aNOJB1s7jHdO4VVbzq9kbcJ60zCDRKxTcyAi.pdf','2025-07-04 14:06:43','2025-07-04 14:06:43'),(5,6,'Evaluation Report','awarddocuments/6LUjMb6BiNt1xK9hNeGBCcrUWPDAoUd3EdDhv9Vj.pdf','2025-07-04 14:25:45','2025-07-04 14:25:45'),(6,6,'Purchase Order','awarddocuments/CwlSCMfrTeRSGwlLJxgcOZdBx74GTRlnQrnnDrV6.pdf','2025-07-04 14:26:00','2025-07-04 14:26:00'),(7,7,'Purchase Order','awarddocuments/xGWzgBoaUzz9mBYJnz3c7U0ZNbaSzBkGShGtsG0Q.pdf','2025-07-07 15:48:06','2025-07-07 15:48:06'),(8,7,'Evaluation Report','awarddocuments/ZroVdcKlSraTUkxSvp4IQxBkGmNFjyumajvhjtMD.pdf','2025-07-07 15:48:37','2025-07-07 15:48:37'),(9,8,'Evaluation Report','awarddocuments/8hSj9yzsVPZfCQSG2RgncNCi5PDECr0tASaQRVC2.pdf','2025-07-09 06:19:26','2025-07-09 06:19:26'),(10,9,'Evaluation Report','awarddocuments/tnMOkXP6Vto2ATz4Du0j3fzfYKq5MJsmGyiEIeCG.pdf','2025-07-29 01:14:07','2025-07-29 01:14:07');
/*!40000 ALTER TABLE `purchaserequisitionawarddocuments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:40
