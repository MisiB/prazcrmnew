-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=656 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (426,'0001_01_01_000000_create_users_table',1),(427,'0001_01_01_000001_create_cache_table',1),(428,'0001_01_01_000002_create_jobs_table',1),(429,'2025_03_18_143847_create_accountsettings_table',1),(430,'2025_03_18_143855_create_accounttypes_table',1),(431,'2025_03_18_143916_create_accounttype_users_table',1),(432,'2025_03_18_143940_create_modules_table',1),(433,'2025_03_18_144053_create_submodules_table',1),(434,'2025_03_18_173956_create_permission_tables',1),(435,'2025_03_19_143703_create_resetpasswords_table',1),(436,'2025_03_20_182448_create_accountypeuser_table',1),(437,'2025_03_31_095042_create_ms_graph_tokens_table',1),(438,'2025_04_01_080917_create_currencies_table',1),(439,'2025_04_01_084800_create_personal_access_tokens_table',1),(440,'2025_04_22_112910_create_banks_table',1),(441,'2025_04_22_134117_create_bankaccounts_table',1),(442,'2025_04_22_143319_create_paynowintegrations_table',1),(443,'2025_04_24_134026_create_inventoryitems_table',1),(444,'2025_04_25_100116_create_customers_table',1),(445,'2025_04_25_100133_create_customernbanks_table',1),(446,'2025_04_25_100507_create_banktransactions_table',1),(447,'2025_04_25_101401_create_banktransactionconversions_table',1),(448,'2025_04_25_101740_create_invoices_table',1),(449,'2025_04_25_102811_create_invoiceconversions_table',1),(450,'2025_04_25_102956_create_suspenses_table',1),(451,'2025_04_25_103406_create_suspenseconversions_table',1),(452,'2025_04_25_103452_create_suspenseutilizations_table',1),(453,'2025_04_25_104115_create_suspenseutilizationconversions_table',1),(454,'2025_04_25_104309_create_onlinepayments_table',1),(455,'2025_04_25_104926_create_onlinepaymentconversions_table',1),(456,'2025_04_25_105954_create_epayments_table',1),(457,'2025_04_26_211343_create_exchangerates_table',2),(469,'2025_04_30_125933_create_tenders_table',3),(470,'2025_04_30_125945_create_tenderfees_table',3),(471,'2025_04_30_130000_create_bidbonds_table',3),(472,'2025_04_30_131538_create_bidbondrefundschedules_table',3),(473,'2025_04_30_131736_create_bidbondrefundschedulelists_table',3),(474,'2025_04_30_132323_create_bidbondrefundscheduleapprovers_table',3),(475,'2025_04_30_133640_create_approvalflows_table',3),(476,'2025_04_30_133652_create_approvalflowstages_table',3),(477,'2025_04_30_133849_create_approvalflowstageusers_table',3),(478,'2025_04_30_134658_create_departments_table',3),(479,'2025_04_30_134703_create_departmentusers_table',3),(480,'2025_05_05_124551_create_monthlysuspensereports_table',4),(481,'2025_05_05_134253_create_tendertypes_table',5),(487,'2025_05_12_114512_create_bankreconciliations_table',6),(488,'2025_05_12_114522_create_bankreconciliationdatas_table',6),(491,'2025_05_29_162340_create_wallettopups_table',7),(492,'2025_05_30_083901_create_departmentusers_table',8),(566,'2025_05_30_140633_create_strategies_table',9),(567,'2025_05_30_140903_create_strategyprogrammes_table',9),(568,'2025_05_30_155749_create_strategyprogrammeoutcomes_table',9),(569,'2025_05_30_155750_create_strategyprogrammeoutcomeindicators_table',9),(570,'2025_05_30_155936_create_strategysubprogrammes_table',9),(571,'2025_05_30_160155_create_strategysubprogrammeoutputs_table',9),(572,'2025_05_30_160156_create_individualoutputs_table',9),(573,'2025_05_30_161336_create_workplans_table',9),(574,'2025_05_30_161740_create_workplantasks_table',9),(575,'2025_06_03_165726_create_individualoutputbreakdowns_table',10),(576,'2025_06_03_173457_create_individualoutputassignees_table',11),(580,'2025_06_17_185824_create_tasks_table',12),(581,'2025_06_18_142433_create_expensecategories_table',13),(582,'2025_06_18_142456_create_sourceoffunds_table',13),(583,'2025_06_18_142539_create_sourceoffundtypes_table',13),(584,'2025_06_18_160544_create_budgets_table',14),(587,'2025_06_18_183756_create_budgetitems_table',15),(590,'2025_06_24_105036_create_budgetvirements_table',16),(592,'2025_06_30_133156_create_purchaserequisitions_table',17),(593,'2025_07_01_111251_create_workflows_table',18),(594,'2025_07_01_111324_create_workflowparameters_table',18),(595,'2025_07_03_082238_create_purchaserequisitionapprovals_table',19),(602,'2025_07_04_111606_create_purchaserequisitionawards_table',20),(603,'2025_07_04_113630_create_purchaserequisitionawarddocuments_table',20),(613,'2025_07_06_134032_create_revenuepostingjobs_table',21),(614,'2025_07_06_151043_create_revenuepostingjobitems_table',21),(629,'2025_07_07_121119_create_paymentrequisitions_table',22),(630,'2025_07_07_124137_create_paymentrequisitionapprovals_table',22),(631,'2025_07_07_124148_create_paymentrequisitiondocuments_table',22),(632,'2025_07_08_173514_create_userapprovalcodes_table',23),(633,'2025_07_16_052408_create_leavetypes_table',24),(634,'2025_07_16_052426_create_leavestatements_table',24),(635,'2025_07_16_052439_create_leaverequests_table',24),(636,'2025_07_16_052449_create_leaverequestapprovals_table',24),(637,'2025_07_23_094348_create_storesrequisitions_table',24),(638,'2025_07_23_094417_create_hodstoresrequisitionapprovals_table',24),(639,'2025_07_23_094440_create_issuerstoresrequisitionapprovals_table',24),(640,'2025_07_23_094505_create_receiverstoresrequisitionapprovals_table',24),(641,'2025_09_14_120352_create_pulse_tables',25),(642,'2025_09_14_122034_create_telescope_entries_table',26),(649,'2025_09_03_103759_create_issuetypes_table',27),(650,'2025_09_03_103831_create_issuegroups_table',27),(651,'2025_09_03_103904_create_issuelogs_table',27),(652,'2025_09_15_130525_create_calendaryears_table',27),(653,'2025_09_15_130545_create_calendarweeks_table',27),(654,'2025_09_15_130928_create_calendardays_table',27),(655,'2025_09_15_180046_create_calenderworkusertasks_table',28);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:34
