-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `leaverequests`
--

DROP TABLE IF EXISTS `leaverequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leaverequests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `leaverequestuuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `leavetype_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `actinghod_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startdate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `enddate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `returndate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `daysappliedfor` int NOT NULL,
  `addressonleave` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reasonforleave` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_src` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leaverequests_leaverequestuuid_unique` (`leaverequestuuid`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaverequests`
--

LOCK TABLES `leaverequests` WRITE;
/*!40000 ALTER TABLE `leaverequests` DISABLE KEYS */;
INSERT INTO `leaverequests` VALUES (1,'7a4f42ad-1e4e-4345-834a-717080f5e83d','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','4',NULL,'2025-09-01','2025-09-02','2025-09-03',2,'1365','for health','leaveattachments/38745c72-d463-4a62-9596-67a4122f22de/G2NRsGGtVHA5o4fFnHhiBFz7mNdDpshrldcM3PlB.pdf','A','2025','2025-08-31 20:55:26','2025-08-31 21:45:47'),(2,'f6cd3fb2-773f-4354-b36e-b6061863f9ad','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','3',NULL,'2025-09-04','2025-09-05','2025-09-08',2,'123','for study',NULL,'A','2025','2025-08-31 22:17:06','2025-08-31 22:19:37'),(3,'c2b05f8a-8f5a-4542-9c0d-16e123dba672','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','5',NULL,'2025-09-08','2025-09-10','2025-09-11',3,'124','for family','leaveattachments/f3b3356f-5de2-4dce-b96a-1633365543aa/MR2VzC3qVtbqYVMH0ntpeBxGBBfvzXUDOU6v2T3A.pdf','C','2025','2025-09-01 08:27:32','2025-09-01 09:00:25'),(4,'c3cfe2b4-5504-4ee7-8e43-2abdecb21f19','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','4',NULL,'2025-09-15','2025-09-17','2025-09-18',3,'123rd','for health','leaveattachments/1ae4e9c2-dd2c-4cfb-92b6-332e448d60b3/LqY8sDzX78gvwVoE464veYvEY7VLTY1qj303EwwF.pdf','C','2025','2025-09-01 09:10:47','2025-09-01 09:28:26'),(5,'ead28e69-fab8-4103-af1a-17b37af85323','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','4',NULL,'2025-09-09','2025-09-17','2025-09-18',7,'123rd','For sick','leaveattachments/d645084a-0ffa-4fb1-9250-e715c3a87129/JyvDO0SJWvx1JFQeLHIzXWQ1GUwUOSfg61SmWCtX.pdf','C','2025','2025-09-01 10:04:53','2025-09-01 10:14:24'),(6,'31b9ede3-0426-43a3-8a3f-ceec03e25672','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','5',NULL,'2025-09-22','2025-09-24','2025-09-25',3,'123','For sick','leaveattachments/b909a676-2749-4be6-b958-22718f166e91','C','2025','2025-09-01 10:14:53','2025-09-01 11:26:21'),(7,'a78fdfaf-506e-4f62-8c4e-47271df47837','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','6',NULL,'2025-09-09','2025-09-17','2025-09-18',7,'123rd','for study','leaveattachments/e1d8f68e-b330-4450-b9a4-da93b2f28fec','A','2025','2025-09-01 11:32:45','2025-09-03 06:05:36'),(8,'3fa3e8bd-269e-4b2b-8b53-d5cedeb19090','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','4',NULL,'2025-09-19','2025-09-20','2025-09-22',1,'123 rd street','for health','leaveattachments/f8bee5e3-4d39-4d7f-ba40-df0b49d4d670','C','2025','2025-09-03 06:10:32','2025-09-04 10:12:52'),(9,'43680869-e83b-4db3-bf16-3133d92d2055','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','6',NULL,'2025-09-22','2025-09-23','2025-09-24',2,'12345','for family','leaveattachments/3f8281b6-6b19-4123-85e7-657797eb1a6d','C','2025','2025-09-04 10:13:39','2025-09-23 15:32:37'),(10,'21eeb86c-05df-4faf-92ba-033ed9089c3f','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd St Kapente, Harare','For school study','leaveattachments/a3b17d9b-3738-43bc-9511-1f84388ea786','C','2025','2025-09-23 12:18:23','2025-09-23 12:35:13'),(11,'f22fc6c3-ed38-4a6c-9341-4c2b63892ff5','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','5',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Kepenga Harare','For school study','leaveattachments/dfa3a1ab-bf7a-4267-a010-334ea080941d','C','2025','2025-09-23 13:18:08','2025-09-23 13:20:34'),(12,'eeba8d8e-a84b-4c6e-82b0-f4d87263453f','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Kepenga Harare','For school study','leaveattachments/851d0686-7678-4cef-995e-de7b3fdb197d','C','2025','2025-09-23 13:21:06','2025-09-23 13:23:55'),(13,'8f5d04ca-f1af-4eaa-93fb-5f607ed12281','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Kepenga Harare','For school study',NULL,'C','2025','2025-09-23 13:25:41','2025-09-23 13:33:06'),(14,'e6dc1d2d-6d33-4329-b6d3-34209635099f','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Kepenga Harare','For school study',NULL,'C','2025','2025-09-23 13:33:39','2025-09-23 13:37:26'),(15,'184f9706-79a8-4618-8265-e3c1e57aa222','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Kepenga Harare','For school study','leaveattachments/8bb38677-9994-4990-86d8-1badecddecc4','C','2025','2025-09-23 13:37:59','2025-09-23 13:39:38'),(16,'f17333af-a8ce-4644-af4d-3bb1487ddc42','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Kepenga Harare','For school study',NULL,'C','2025','2025-09-23 13:40:01','2025-09-23 13:46:18'),(17,'481ffb7b-d2ba-4f13-8c26-5d5f1270df20','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','6',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Kepenga Harare','For school study','leaveattachments/8571507e-583a-436a-b035-50c70770f2ce','A','2025','2025-09-23 13:48:23','2025-09-23 13:56:28'),(18,'812e164a-4e84-4a7c-a876-ddbc5cc458e6','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Foukange St','For school study',NULL,'C','2025','2025-09-23 15:33:10','2025-09-23 15:34:44'),(19,'75d724f3-e389-4c8b-ba00-5c7a04ba9985','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Foukange St','For school study',NULL,'C','2025','2025-09-23 15:36:36','2025-09-23 16:19:59'),(20,'863cedd6-12e5-4ff4-8cd0-bde7436b4a19','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','3','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-10-01','2025-10-03','2025-10-06',3,'23rd Foukange St','For school study',NULL,'C','2025','2025-09-23 16:20:33','2025-09-24 05:07:09'),(21,'20a7b9ac-5a57-4ac6-83ae-d071048f308b','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','3','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-10-01','2025-10-03','2025-10-06',3,'23rd ST ROSBED','For school study','leaveattachments/e7c14384-c63a-45c7-8d1d-25a2282582ad','A','2025','2025-09-24 05:37:43','2025-09-24 05:47:01'),(22,'fe12341a-a2bc-45c8-a8b7-6b6cdf9ce150','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd ST ROSBED','For school study','leaveattachments/b9c77a2c-bd88-4cd2-abd4-82b6e3fa6c75','C','2025','2025-09-24 05:55:02','2025-09-24 06:49:46'),(23,'dc2cbc23-df8a-4c10-8540-45ab4a00b102','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'For approval','For school study','leaveattachments/3e2757c0-ceb9-4dc5-915e-d4a3a70204dc','C','2025','2025-09-24 06:50:13','2025-09-24 07:47:56'),(24,'23793136-6d54-4885-949e-7109f2e2c2eb','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'For school study','For school study','leaveattachments/4a1d29db-1348-4a74-a7a4-9ef32b87a489','C','2025','2025-09-24 07:48:27','2025-09-24 07:49:23'),(25,'f3a98c15-def3-4514-aaeb-29533cba2862','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd st brewery lawrence ks','For school study','leaveattachments/340224a0-c67f-42be-b1e5-095aeeec8118','C','2025','2025-09-24 07:51:43','2025-09-24 07:53:08'),(26,'de8b26d9-1e34-41c8-a160-9d3e2d8149f9','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd st brewery lawrence ks','For school study',NULL,'C','2025','2025-09-24 07:53:27','2025-09-24 07:55:15'),(27,'caf4d247-2930-41fa-9300-eb0bd8bfdf0c','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'113rd St','For school study','leaveattachments/7842b34c-820f-466a-a5f4-92550bcba2f3','C','2025','2025-09-24 08:17:52','2025-09-24 08:29:12'),(28,'8d84d707-3f7d-432d-b159-88f676b25ee4','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Lafet ST','For school study','leaveattachments/f4d43e16-b64d-4eae-a085-211f3700348b','C','2025','2025-09-24 08:34:54','2025-09-24 08:41:13'),(29,'f017be5f-8f50-4013-bc55-29f72438073e','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Lafet ST','For school study','leaveattachments/6889e314-e052-40d6-9c04-1e0af6542f39','C','2025','2025-09-24 08:43:28','2025-09-24 08:48:07'),(30,'e8b68513-c262-42aa-80f3-888976f319e0','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd Lafet ST','For school study','leaveattachments/59ea6161-2ada-4286-b7e0-b39aa5103134','C','2025','2025-09-24 08:51:42','2025-09-24 08:56:42'),(31,'82911440-e008-460f-a522-d4d9761e317d','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'23rd ST','For school study','leaveattachments/1f344547-65d5-4d6c-8c5a-fc62e01b068b','C','2025','2025-09-24 09:05:23','2025-09-24 09:43:45'),(32,'0426b6b0-818e-4d5e-a93f-18ee3abb2365','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','3','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-10-07','2025-10-08','2025-10-09',2,'123rd ST','for study',NULL,'C','2025','2025-09-24 09:58:24','2025-09-24 10:11:03'),(33,'e78477e8-e416-4d75-9b11-2d0e7b0f4d63','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','3','9cb5cca6-9d6b-41d2-90ef-2f8ca4fbad3d','2025-10-07','2025-10-08','2025-10-09',2,'for study','for study',NULL,'A','2025','2025-09-24 10:11:51','2025-09-24 10:52:19'),(34,'ca0020cb-e578-45a6-983c-ed6b100e7dc5','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'123rd Rd','For school study',NULL,'C','2025','2025-09-24 11:18:28','2025-09-24 11:20:03'),(35,'58e291a0-7ffd-4ff2-9826-a4d72ad5896c','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'12RD STREET','For school study',NULL,'C','2025','2025-09-24 11:20:46','2025-09-24 11:29:07'),(36,'c7137622-55fd-45a2-936a-158029eb0c91','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'12rd','For school study',NULL,'C','2025','2025-09-24 11:42:56','2025-09-24 11:54:46'),(37,'62811b78-297a-407c-a722-fad359e16827','9d15a84c-b2df-4c4d-9c6c-be69ebc0314a','3',NULL,'2025-10-01','2025-10-03','2025-10-06',3,'123rd ST','For school study',NULL,'P','2025','2025-09-24 11:55:59','2025-09-24 11:55:59');
/*!40000 ALTER TABLE `leaverequests` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:34:56
