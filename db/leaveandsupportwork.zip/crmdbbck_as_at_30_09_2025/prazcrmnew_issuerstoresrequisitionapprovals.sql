-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `issuerstoresrequisitionapprovals`
--

DROP TABLE IF EXISTS `issuerstoresrequisitionapprovals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issuerstoresrequisitionapprovals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `storesrequisition_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decision` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issuerstoresrequisitionapprovals`
--

LOCK TABLES `issuerstoresrequisitionapprovals` WRITE;
/*!40000 ALTER TABLE `issuerstoresrequisitionapprovals` DISABLE KEYS */;
INSERT INTO `issuerstoresrequisitionapprovals` VALUES (1,'b6591ddd-7062-4fea-a838-ca6e2a6a0f77','9e86a252-68a9-47e4-b688-0d04387f594c','Notepads are out of stock',1,'2025-08-28 14:34:47','2025-08-28 16:30:10'),(2,'e0f9c436-2dd9-4edc-840b-180b7d0ca83e','9e86a252-68a9-47e4-b688-0d04387f594c','Delivered',1,'2025-08-28 17:20:33','2025-08-28 17:21:10'),(3,'13925e78-466c-4270-abb5-4a3230b5c92e','9e86a252-68a9-47e4-b688-0d04387f594c','Issued',1,'2025-08-29 13:54:16','2025-08-30 15:06:09'),(4,'b65c732f-0188-444e-b529-d3c5241a1af6','9e86a252-68a9-47e4-b688-0d04387f594c','Delivered',1,'2025-08-29 13:54:42','2025-08-29 13:55:19'),(5,'fc95a926-4cb2-461a-bea1-7546b8b1180f','9e86a252-68a9-47e4-b688-0d04387f594c','Successfully acquired',1,'2025-08-29 14:14:35','2025-08-29 14:15:13'),(6,'57e0e1a0-eee7-4a50-b4a6-fe4591eb9067','9e86a252-68a9-47e4-b688-0d04387f594c','Issued',1,'2025-08-30 14:37:23','2025-08-30 14:40:26'),(7,'22167741-a377-4cd4-8e6e-343beb63bae4','9e86a252-68a9-47e4-b688-0d04387f594c','Issued',1,'2025-08-30 14:57:05','2025-08-30 14:57:34'),(8,'23fab05a-1e6a-46e7-b7c1-b34d67ee20e6','9e86a252-68a9-47e4-b688-0d04387f594c','Issued',1,'2025-08-30 15:00:57','2025-08-30 15:01:34'),(9,'a4b0e7e6-66ea-406a-bd2b-4eef32f74794','9e86a252-68a9-47e4-b688-0d04387f594c','Issued',1,'2025-08-30 16:17:27','2025-08-30 16:19:27'),(10,'9b37470d-1044-45bf-b8d8-2d9a5989bbef','9e86a252-68a9-47e4-b688-0d04387f594c','Issued',1,'2025-08-30 16:36:10','2025-08-30 16:37:07'),(11,'cc4dbec4-0dce-4e73-91a3-52614c51b8f6','9e86a252-68a9-47e4-b688-0d04387f594c',NULL,NULL,'2025-08-30 16:36:52','2025-08-30 16:36:52'),(12,'f708dc14-3c6b-4c1c-95c2-34c0d260dabf','9cb7c72c-ff8d-49b6-a591-4593ba885f2c','Delivered',1,'2025-09-18 13:20:34','2025-09-18 13:22:35');
/*!40000 ALTER TABLE `issuerstoresrequisitionapprovals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:41
