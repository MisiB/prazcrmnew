-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hodstoresrequisitionapprovals`
--

DROP TABLE IF EXISTS `hodstoresrequisitionapprovals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hodstoresrequisitionapprovals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `storesrequisition_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decision` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hodstoresrequisitionapprovals`
--

LOCK TABLES `hodstoresrequisitionapprovals` WRITE;
/*!40000 ALTER TABLE `hodstoresrequisitionapprovals` DISABLE KEYS */;
INSERT INTO `hodstoresrequisitionapprovals` VALUES (1,'cdf1a473-d995-416e-8cd4-a5064cf195c2','9c97ca3f-bb84-4127-8273-ef8d2048746d','Not required anymore',0,'2025-08-28 04:24:35','2025-08-29 10:55:55'),(2,'b6591ddd-7062-4fea-a838-ca6e2a6a0f77','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Accepted',1,'2025-08-28 04:45:49','2025-08-28 11:20:21'),(3,'e0f9c436-2dd9-4edc-840b-180b7d0ca83e','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Approve',1,'2025-08-28 04:56:30','2025-08-28 17:19:51'),(4,'f7f61e5f-b368-4ce9-8f6c-4fe4c623f4e6','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'2025-08-28 04:57:08','2025-08-28 04:57:08'),(5,'76287ec2-1ce3-4136-ad82-691352b793f8','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'2025-08-28 04:57:30','2025-08-28 04:57:30'),(6,'36d1c83f-e3c0-4256-95fb-0b1f4bd579a8','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'2025-08-28 04:58:03','2025-08-28 04:58:03'),(7,'b65c732f-0188-444e-b529-d3c5241a1af6','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approved as required',1,'2025-08-28 04:58:44','2025-08-29 01:12:04'),(8,'77aa83dc-267e-4feb-bfbf-ff8c5ae2bea9','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'2025-08-28 04:59:03','2025-08-28 04:59:03'),(9,'fa584ebf-8a82-4e0c-8fc9-77226d0d2e95','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'2025-08-28 04:59:24','2025-08-28 04:59:24'),(10,'cc4dbec4-0dce-4e73-91a3-52614c51b8f6','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approved',1,'2025-08-28 05:02:16','2025-08-29 01:17:58'),(11,'13925e78-466c-4270-abb5-4a3230b5c92e','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approved',1,'2025-08-28 05:02:38','2025-08-29 12:45:20'),(12,'2eb21b94-22af-4044-a32c-08133f1b10dc','9c97ca3f-bb84-4127-8273-ef8d2048746d',NULL,NULL,'2025-08-28 05:03:08','2025-08-28 05:03:08'),(13,'352b22a6-b9b3-45aa-aa94-0fba7798ec26','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'2025-08-28 09:38:44','2025-08-28 09:38:44'),(14,'fc95a926-4cb2-461a-bea1-7546b8b1180f','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approved as required',1,'2025-08-29 14:07:44','2025-08-29 14:11:50'),(15,'88c3460a-914e-4bee-acd8-535841cf7fa5','9c97ca3f-bb84-4127-8273-ef8d2048746d',NULL,NULL,'2025-08-29 15:51:05','2025-08-29 15:51:05'),(16,'57e0e1a0-eee7-4a50-b4a6-fe4591eb9067','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approved from an approval email notification',1,'2025-08-30 13:44:13','2025-08-30 13:52:27'),(17,'22167741-a377-4cd4-8e6e-343beb63bae4','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approved from email notification',1,'2025-08-30 14:04:18','2025-08-30 14:05:57'),(18,'23fab05a-1e6a-46e7-b7c1-b34d67ee20e6','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approve from email notification',1,'2025-08-30 14:33:20','2025-08-30 14:34:18'),(19,'a4b0e7e6-66ea-406a-bd2b-4eef32f74794','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approved via email notification',1,'2025-08-30 16:04:21','2025-08-30 16:10:30'),(20,'9b37470d-1044-45bf-b8d8-2d9a5989bbef','9c97ca3f-bb84-4127-8273-ef8d2048746d','approved via email',1,'2025-08-30 16:28:44','2025-08-30 16:29:19'),(21,'30107ecc-3365-44ab-92ce-96ae808a3dc4','9d7a657a-a7ea-453c-a9fb-a40931a7aa41',NULL,NULL,'2025-08-31 19:16:34','2025-08-31 19:16:34'),(22,'f708dc14-3c6b-4c1c-95c2-34c0d260dabf','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Approved as required',1,'2025-09-18 10:43:07','2025-09-18 11:25:54'),(23,'c8258f55-77a2-4629-888b-13b1aa179e06','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Approved and needed by the department',1,'2025-09-19 08:42:03','2025-09-19 08:45:20'),(24,'67753bd5-0c8f-4831-9094-57572c246e89','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0',NULL,NULL,'2025-09-19 08:44:05','2025-09-19 08:44:05'),(25,'8a2c3a9b-bf5e-4bdb-bf7c-317c1369b890','9c8ce0e6-c173-4a9a-8483-0f9ad09d33b0','Required',1,'2025-09-19 08:46:46','2025-09-19 08:47:15');
/*!40000 ALTER TABLE `hodstoresrequisitionapprovals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:34:59
