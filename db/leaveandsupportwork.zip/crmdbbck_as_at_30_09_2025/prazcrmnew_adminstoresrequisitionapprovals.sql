-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: prazcrmnew
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adminstoresrequisitionapprovals`
--

DROP TABLE IF EXISTS `adminstoresrequisitionapprovals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adminstoresrequisitionapprovals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `storesrequisition_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decision` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminstoresrequisitionapprovals`
--

LOCK TABLES `adminstoresrequisitionapprovals` WRITE;
/*!40000 ALTER TABLE `adminstoresrequisitionapprovals` DISABLE KEYS */;
INSERT INTO `adminstoresrequisitionapprovals` VALUES (1,'b6591ddd-7062-4fea-a838-ca6e2a6a0f77','9d7a657a-a7ea-453c-a9fb-a40931a7aa41',NULL,NULL,'2025-08-28 16:30:10','2025-08-28 16:30:10'),(2,'e0f9c436-2dd9-4edc-840b-180b7d0ca83e','9d7a657a-a7ea-453c-a9fb-a40931a7aa41','Verified',1,'2025-08-28 17:21:10','2025-08-28 23:48:04'),(3,'b65c732f-0188-444e-b529-d3c5241a1af6','9d7a657a-a7ea-453c-a9fb-a40931a7aa41',NULL,NULL,'2025-08-29 13:55:19','2025-08-29 13:55:19'),(4,'fc95a926-4cb2-461a-bea1-7546b8b1180f','9d7a657a-a7ea-453c-a9fb-a40931a7aa41','Approved',1,'2025-08-29 14:15:13','2025-08-29 14:23:51'),(5,'57e0e1a0-eee7-4a50-b4a6-fe4591eb9067','9d7a657a-a7ea-453c-a9fb-a40931a7aa41',NULL,NULL,'2025-08-30 14:40:26','2025-08-30 14:40:26'),(6,'22167741-a377-4cd4-8e6e-343beb63bae4','9d7a657a-a7ea-453c-a9fb-a40931a7aa41',NULL,NULL,'2025-08-30 14:57:34','2025-08-30 14:57:34'),(7,'23fab05a-1e6a-46e7-b7c1-b34d67ee20e6','9d7a657a-a7ea-453c-a9fb-a40931a7aa41',NULL,NULL,'2025-08-30 15:01:34','2025-08-30 15:01:34'),(8,'13925e78-466c-4270-abb5-4a3230b5c92e','9d7a657a-a7ea-453c-a9fb-a40931a7aa41','I verify delivery via email notification',1,'2025-08-30 15:06:09','2025-08-30 15:09:15'),(9,'a4b0e7e6-66ea-406a-bd2b-4eef32f74794','9d7a657a-a7ea-453c-a9fb-a40931a7aa41','Approve  via email',1,'2025-08-30 16:19:27','2025-08-30 16:20:04'),(10,'9b37470d-1044-45bf-b8d8-2d9a5989bbef','9d7a657a-a7ea-453c-a9fb-a40931a7aa41','Approved',1,'2025-08-30 16:37:07','2025-08-30 16:38:23'),(11,'f708dc14-3c6b-4c1c-95c2-34c0d260dabf','9c97ca3f-bb84-4127-8273-ef8d2048746d','Approved',1,'2025-09-18 13:22:35','2025-09-18 13:29:15');
/*!40000 ALTER TABLE `adminstoresrequisitionapprovals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-30 14:35:52
